
##########################################################################################
#
#  V-Combo SYNTH  * whats new *  
#
##########################################################################################

=> see also: editor user manual from Raymond 
             video-tutorials on youtube (search for "Roland VR09 VR730 V-Combo SYNTH Windows" or "Roland VR09 VR730 V-Combo EDITOR Windows") 


===========================================================================================
V1.12(9) "hotfix version'
===========================================================================================
* MAJOR BUG: in the 'SYNTHESIZER' tab, the DEL-button of the registration destroys the registration file of the EDITOR => fixed

========================================================================================
V1.12(8) "initial version"
===========================================================================================
* CTRLR panel with functionality of the V-Combo EDITOR - SYNTHESIZER-tab with extended surface for studio/home use:

  - working area optimzied for big monitors for simultaneous control of all three partials  
  - reduced number of voices (only 2 in upper manual)
  - sound-patch selector reduced to synthesizable sounds 
  - intergrated simple arpeggio-sequencer 'ARP SEQ' (for MS-Windows only) to help sound editing
  - quick lauchner for CopperLan (needed for the sequencer)
  - patch registration shared with V-Combo EDITOR 
  - user-friendly documentation created by VR-musician Raymond (for EDITOR, but applicable to SYNTH):
    https://drive.google.com/drive/folders/1uGuVOTOpudkNxrDMgu8eFfpbYaxVbbp


