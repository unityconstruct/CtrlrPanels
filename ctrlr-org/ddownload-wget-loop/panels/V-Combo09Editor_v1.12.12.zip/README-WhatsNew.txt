##########################################################################################
#
#  V-Combo Editor                * whats new *  
#
##########################################################################################

Overview: See 'v1.12.xy README' on EDITOR Main panel 
Details:  See 'Version Info' on EDITOR KBD-CONFIG 'QuickHelp'

