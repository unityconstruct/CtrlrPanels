                                __                       ___________            __          
  _____   ____   ____   _______/  |________ __ __  _____ \_   _____/___   _____/  |_  ______
 /     \ /  _ \ /    \ /  ___/\   __\_  __ \  |  \/     \ |    __)/  _ \ /    \   __\/  ___/
|  Y Y  (  <_> )   |  \\___ \  |  |  |  | \/  |  /  Y Y  \|     \(  <_> )   |  \  |  \___ \ 
|__|_|  /\____/|___|  /____  > |__|  |__|  |____/|__|_|  /\___  / \____/|___|  /__| /____  >
      \/            \/     \/                          \/     \/             \/          \/

Installing this font package will make your monstrumMedia MIDI panel display fonts as they should. 




For Windows users

- Right-click the font file(s) and choose "Install".

For users of the previous Windows versions:

- Copy the included file(s) into a default Windows font folder 
  (usually C:\WINDOWS\FONTS or C:\WINNT\FONTS)



For Mac users:

Mac OS X 10.3 or above (including the FontBook)

- Double-click the font file and hit "Install font" button at 
  the bottom of the preview.

Mac OS X

- Either copy the font file(s) to /Library/Fonts (for all users), 
  or to /Users/Your_username/Library/Fonts (for you only).

Mac OS 9 or earlier

- You have to convert the font file(s) you have downloaded. 
  Drag the font suitcases into the System folder. The system 
  will propose you to add them to the Fonts folder.



For Linux users:

- Copy the font file(s) to /USR/SHARE/FONTS




All fonts also available for free download from:

Futura MdCn BT: http://fontzone.net/font-details/Futura+Medium+Condensed+BT/
LCDDOT-TR: http://en.fonts2u.com/lcddot-tr-regular.font

This package is being redistributed with due credits given under free license, by monstrum media, 2013

www.monstrummedia.com

