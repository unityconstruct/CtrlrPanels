##########################################################################################
#
#  V-Combo 700 Editor               * whats new *  
#
##########################################################################################

Documentation:
- Download the interactive EDITOR documentation from the EDITOR CTRLR website, unpack the zip and open 'V-Combo700_Tutorial_en.html' 
  with your Web-Browser
- Eventually vatch the 'VR09/730 EDITOR' video-tutorials on youtube (search for "Roland VR09 VR730 V-Combo EDITOR Windows") 

===========================================================================================
V1.01(2) "Bugfix Version"
===========================================================================================
* BUG: KBD-CONIFIG => MIDI CONFIG: setting Vlink channel makes EDITOR disfunctional

===========================================================================================
V1.01(1) "Initial version'
===========================================================================================
* Main Features
    - Application for MS Windows (XP/7/8/10),  OSX and Linux for the control of Roland VR700
    - Easy access to VR700 sounds and parameters instead of cruel menu diving in the WDOAT (worst display of all times)
    - Hammond style organ with 2 drawbar sets and (customizable) presets
    - Organ preset switching in Hammond-style with the lower VR-keys
    - Additional effects for ensemble sounds (filter, ADR envelope, virbrato, special FX ...)
    - Free choice of MFX-EFFECT (out of 256 MFX) for each sound + controls of MFX parameters (like VR760)
    - Extended rhythm control (change of drum kit and drum sound manipulation)
    - proprietary EDITOR registration (independent from VR favorites) : 2048 registrations, custom registration naming, 
      saving of additional EFX (like envelope, filter, extended rhythm controls, vibrato settings etc)
    - proprietary EDITOR single sound registration : fast 'workflow' register to 'backup' single ensemble sounds 
      (e.g. your modified pianos, enhanced strings etc)
    - Switching of the VR-Favorites with the EDITOR
    - Switching of the EDITOR registrations with the Favorite buttons and/or footswitch of the VR700
    - Switch the EDITOR registrations from an external program/controller
    - Quick access footswitch configurator for live play
    - Synthesizer work mode for ensemble sounds: the drawbars and GAIN+REVERB knob act as filter and resonance faders
    - enhanced EQUALIZER
    - UPG file editor for reordering the favorites in a Favorite backup ("UPG") files
    - Built in sequencer (Win only) and external program launcher

